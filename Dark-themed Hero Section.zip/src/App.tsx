import { useState } from "react"

const dataNodes = [
  { cx: 188, cy: 87, r: 5 },
  { cx: 323, cy: 58, r: 4 },
  { cx: 426, cy: 137, r: 6 },
  { cx: 258, cy: 190, r: 5 },
  { cx: 98, cy: 220, r: 4 },
  { cx: 380, cy: 282, r: 4 },
  { cx: 210, cy: 338, r: 6 },
  { cx: 482, cy: 366, r: 5 },
  { cx: 315, cy: 448, r: 4 },
  { cx: 118, cy: 417, r: 5 },
]

const stackCategories = [
  {
    number: "01",
    title: "Data Engineering",
    description: "Reliable systems built to move, transform, and serve data at scale.",
    tools: ["Python", "SQL", "Apache Spark", "Airflow", "Kafka", "dbt"],
  },
  {
    number: "02",
    title: "Data Science & ML",
    description: "Focused modeling workflows that turn uncertainty into clear outcomes.",
    tools: ["Pandas", "TensorFlow", "PyTorch", "scikit-learn", "NumPy", "MLflow"],
  },
  {
    number: "03",
    title: "Cloud & DevOps",
    description: "Production infrastructure designed for resilience and repeatable delivery.",
    tools: ["AWS", "Docker", "Kubernetes", "Terraform", "GitHub Actions", "Linux"],
  },
]

const pipelineStages = [
  {
    number: "01",
    title: "Raw Sources",
    label: "INPUT LAYER",
    detail: "APIs · Events · Databases",
    type: "sources",
  },
  {
    number: "02",
    title: "Ingestion & Processing",
    label: "COMPUTE LAYER",
    detail: "Stream · Batch · Transform",
    type: "processing",
  },
  {
    number: "03",
    title: "Data Vault",
    suffix: "(Warehouse)",
    label: "STORAGE LAYER",
    detail: "Modeled · Tested · Governed",
    type: "vault",
  },
  {
    number: "04",
    title: "Output & ML Models",
    label: "INTELLIGENCE LAYER",
    detail: "Predict · Visualize · Decide",
    type: "output",
  },
] as const

const chartSeries = {
  "7 Days": [34, 42, 38, 55, 49, 68, 74, 66, 82, 78, 91, 96],
  "1 Month": [28, 35, 32, 44, 41, 52, 48, 63, 69, 65, 78, 86],
  "1 Year": [18, 23, 31, 28, 39, 47, 43, 57, 62, 71, 77, 89],
} as const

type ChartPeriod = keyof typeof chartSeries

const featuredProjects = [
  {
    index: "01",
    title: "Real-Time Anomaly Detection",
    type: "anomaly",
    fog: "Critical failures were buried inside 14M daily sensor events.",
    strategy: "Built a streaming feature pipeline with adaptive detection thresholds.",
    vision: "Cut incident response time by 73% while reducing false alerts.",
    stack: "PYTHON / KAFKA / SPARK",
  },
  {
    index: "02",
    title: "Demand Intelligence Engine",
    type: "forecast",
    fog: "Static forecasts left inventory teams reacting weeks too late.",
    strategy: "Deployed a probabilistic model blending sales, seasonality, and market signals.",
    vision: "Improved forecast accuracy by 31% across 1,200 product lines.",
    stack: "PYTORCH / AIRFLOW / AWS",
  },
  {
    index: "03",
    title: "Unified Customer Vault",
    type: "vault",
    fog: "Fragmented records obscured the true customer journey.",
    strategy: "Engineered an identity-resolution layer and governed warehouse model.",
    vision: "Created one trusted view used by six cross-functional teams.",
    stack: "DBT / SNOWFLAKE / SQL",
  },
] as const

const experienceTimeline = [
  {
    year: "2025",
    role: "Lead Data Architect",
    description:
      "Designing resilient, cloud-native data platforms that unify real-time intelligence and governed analytics.",
    focus: "SYSTEM DESIGN / STRATEGY",
  },
  {
    year: "2023",
    role: "Senior Data Engineer",
    description:
      "Scaled event-driven pipelines and transformed fragmented services into a dependable data ecosystem.",
    focus: "STREAMING / PLATFORM",
  },
  {
    year: "2021",
    role: "Machine Learning Engineer",
    description:
      "Moved predictive models beyond notebooks into observable, repeatable production workflows.",
    focus: "MLOPS / INFERENCE",
  },
  {
    year: "2019",
    role: "Data Scientist",
    description:
      "Translated ambiguous business questions into clear experiments, forecasts, and decision-ready stories.",
    focus: "MODELING / INSIGHT",
  },
  {
    year: "2017",
    role: "The First Script",
    description:
      "Automated a repetitive problem with Python and discovered the leverage hidden inside well-structured data.",
    focus: "PYTHON / CURIOSITY",
  },
] as const

const engineeringPrinciples = [
  {
    number: "01",
    title: "Clean Data > Complex Models",
    description:
      "A sophisticated model cannot rescue a broken foundation. I prioritize observable, tested, and trustworthy data before adding complexity.",
    code: "QUALITY / CLARITY",
  },
  {
    number: "02",
    title: "Scalable Architecture",
    description:
      "Systems should grow without becoming fragile. I design modular foundations that remain clear under greater volume, velocity, and change.",
    code: "SCALE / RESILIENCE",
  },
  {
    number: "03",
    title: "Security in the Fog",
    description:
      "Trust is an architectural requirement, not an afterthought. Every pipeline should protect access, lineage, and sensitive information by design.",
    code: "TRUST / GOVERNANCE",
  },
] as const

const postMortems = [
  {
    id: "INC-042",
    title: "The Silent Schema Drift",
    date: "2024.08.17",
    system: "STREAM_PROCESSOR",
    crash:
      "A vendor changed a nested event field without notice. The pipeline stayed green while quietly dropping 18% of incoming records.",
    fix:
      "Quarantined malformed events, replayed the raw topic, and introduced contract validation at every ingestion boundary.",
    lesson:
      "A successful job is not the same as correct data. Monitor business invariants, not just infrastructure health.",
    terms: "SCHEMA REGISTRY / DLQ / REPLAY",
  },
  {
    id: "INC-057",
    title: "The Costly Cartesian Join",
    date: "2025.02.03",
    system: "FEATURE_PIPELINE",
    crash:
      "An overlooked many-to-many join multiplied a feature table beyond memory limits and brought the overnight model run to a halt.",
    fix:
      "Stopped the workflow, corrected the grain, added cardinality assertions, and backfilled only the affected partitions.",
    lesson:
      "Define data grain before writing the join. Scale magnifies assumptions faster than it magnifies value.",
    terms: "SPARK / ASSERTIONS / PARTITIONING",
  },
] as const

const certifications = [
  {
    rank: "CERT / 01",
    title: "AWS Certified",
    subtitle: "Data Analytics — Specialty",
    type: "cloud",
  },
  {
    rank: "CERT / 02",
    title: "GCP Data Engineer",
    subtitle: "Professional Certification",
    type: "network",
  },
  {
    rank: "CERT / 03",
    title: "Databricks Engineer",
    subtitle: "Data Engineer — Professional",
    type: "lakehouse",
  },
  {
    rank: "RANK / 04",
    title: "Kaggle Silver",
    subtitle: "Competition Medalist",
    type: "competition",
  },
] as const

const logbookEntries = [
  {
    date: "MAY 18, 2025",
    readTime: "08 MIN",
    category: "DATA ARCHITECTURE",
    title: "The Cost of a Pipeline Nobody Understands",
    excerpt:
      "Why operational clarity matters more than clever abstractions when a data platform begins to scale across teams.",
  },
  {
    date: "APR 02, 2025",
    readTime: "06 MIN",
    category: "MACHINE LEARNING",
    title: "Your Model Is Not the Product",
    excerpt:
      "A field note on the systems, interfaces, and human decisions that turn a strong prediction into measurable value.",
  },
  {
    date: "FEB 21, 2025",
    readTime: "11 MIN",
    category: "DATA QUALITY",
    title: "Monitoring the Truth, Not Just the Job",
    excerpt:
      "Green dashboards can still deliver broken data. These are the invariants I monitor beyond pipeline uptime.",
  },
  {
    date: "JAN 09, 2025",
    readTime: "05 MIN",
    category: "ENGINEERING CULTURE",
    title: "Silence as a Technical Advantage",
    excerpt:
      "How deep work, deliberate communication, and fewer handoffs produce calmer systems and better engineering decisions.",
  },
] as const

function DataNetwork() {
  return (
    <div className="network-wrap" aria-hidden="true">
      <div className="network-orbit network-orbit-one" />
      <div className="network-orbit network-orbit-two" />

      <svg
        className="network-svg"
        viewBox="0 0 560 540"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g className="network-lines">
          <path d="M98 220L188 87L258 190L98 220Z" />
          <path d="M188 87L323 58L426 137L258 190L188 87Z" />
          <path d="M258 190L380 282L210 338L98 220L258 190Z" />
          <path d="M426 137L380 282L482 366L258 190" />
          <path d="M210 338L315 448L482 366L380 282L210 338Z" />
          <path d="M98 220L118 417L210 338" />
          <path d="M118 417L315 448" />
          <path d="M323 58L380 282" />
        </g>

        <g className="network-dashes">
          <path d="M188 87L380 282" />
          <path d="M426 137L210 338" />
          <path d="M258 190L315 448" />
        </g>

        <g className="network-faces">
          <path d="M188 87L258 190L380 282L323 58Z" />
          <path d="M98 220L210 338L258 190Z" />
          <path d="M210 338L315 448L380 282Z" />
        </g>

        <g className="network-points">
          {dataNodes.map((node, index) => (
            <g key={`${node.cx}-${node.cy}`}>
              <circle
                className={index === 3 ? "node-halo node-halo-active" : "node-halo"}
                cx={node.cx}
                cy={node.cy}
                r={node.r + 10}
              />
              <circle
                className={index === 3 ? "node node-active" : "node"}
                cx={node.cx}
                cy={node.cy}
                r={node.r}
              />
            </g>
          ))}
        </g>

        <g className="data-label">
          <rect x="281" y="167" width="102" height="35" rx="2" />
          <text x="297" y="188">
            SIGNAL 0.97
          </text>
        </g>

        <g className="axis-marks">
          <path d="M68 468H108M68 468V428" />
          <path d="M492 73H452M492 73V113" />
        </g>
      </svg>

      <div className="network-meta network-meta-top">
        <span>01</span>
        <span>INGEST</span>
      </div>
      <div className="network-meta network-meta-bottom">
        <span>02</span>
        <span>INFERENCE</span>
      </div>
    </div>
  )
}

function CertificationBadge({
  type,
}: {
  type: (typeof certifications)[number]["type"]
}) {
  return (
    <svg className="certification-badge" viewBox="0 0 180 210" aria-hidden="true">
      <path
        className="badge-outer"
        d="M90 8 157 32v68c0 48-27 80-67 101-40-21-67-53-67-101V32L90 8Z"
      />
      <path
        className="badge-inner"
        d="M90 22 144 42v57c0 38-20 65-54 84-34-19-54-46-54-84V42L90 22Z"
      />
      <path className="badge-top-mark" d="M74 35h32" />

      {type === "cloud" && (
        <g className="badge-glyph">
          <path d="M58 108h63c10 0 18-8 18-18 0-9-7-17-16-18-4-18-20-31-39-31-21 0-38 16-40 37-9 2-16 10-16 20 0 11 9 20 20 20h10" />
          <path d="m71 105 19-19 19 19M90 86v45" />
        </g>
      )}

      {type === "network" && (
        <g className="badge-glyph">
          <circle cx="90" cy="84" r="13" />
          <circle cx="58" cy="122" r="9" />
          <circle cx="122" cy="122" r="9" />
          <path d="m81 94-18 20M99 94l18 20M67 122h46" />
          <path d="M82 84h16M90 76v16" />
        </g>
      )}

      {type === "lakehouse" && (
        <g className="badge-glyph">
          <path d="m90 49 42 21-42 21-42-21 42-21Z" />
          <path d="m48 88 42 21 42-21M48 106l42 21 42-21" />
          <path className="badge-accent-fill" d="m90 62 17 8-17 9-17-9 17-8Z" />
        </g>
      )}

      {type === "competition" && (
        <g className="badge-glyph">
          <path d="M61 55h58v48c0 16-13 29-29 29s-29-13-29-29V55Z" />
          <path d="M61 67H44v14c0 13 9 23 22 25M119 67h17v14c0 13-9 23-22 25M90 132v18M72 150h36" />
          <path className="badge-accent-fill" d="m90 68 5 11 12 1-9 8 3 12-11-6-11 6 3-12-9-8 12-1 5-11Z" />
        </g>
      )}

      <circle className="badge-rivet" cx="90" cy="176" r="3" />
    </svg>
  )
}

function PantherMark() {
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true">
      <path className="panther-outline" d="m7 9 11 6h12L41 9l-3 19-14 12L10 28 7 9Z" />
      <path className="panther-planes" d="m10 14 10 8-5 10M38 14l-10 8 5 10M20 22h8l-4 17-4-17Z" />
      <path className="panther-eyes" d="m13 23 7 2-6 3M35 23l-7 2 6 3" />
      <path className="panther-nose" d="m20 33 4 2 4-2-4 6-4-6Z" />
    </svg>
  )
}

function PantherChat() {
  const [isOpen, setIsOpen] = useState(true)
  const [query, setQuery] = useState("")
  const [userMessage, setUserMessage] = useState("Does he know Python and AWS?")

  function submitQuery(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const nextQuery = query.trim()

    if (!nextQuery) return

    setUserMessage(nextQuery)
    setQuery("")
  }

  return (
    <aside className="panther-chat" aria-label="Panther AI assistant">
      {isOpen && (
        <div className="chat-window">
          <span className="chat-corner chat-corner-top" aria-hidden="true" />
          <span className="chat-corner chat-corner-bottom" aria-hidden="true" />

          <header className="chat-header">
            <div className="chat-identity">
              <span className="chat-avatar">
                <PantherMark />
              </span>
              <div>
                <strong>Panther AI</strong>
                <span>// Digital Shadow</span>
              </div>
            </div>
            <button
              className="chat-close"
              type="button"
              aria-label="Close Panther AI"
              onClick={() => setIsOpen(false)}
            >
              ×
            </button>
          </header>

          <div className="chat-readout" aria-hidden="true">
            <span>NEURAL LINK / ACTIVE</span>
            <span>ENCRYPTED</span>
          </div>

          <div className="chat-messages" aria-live="polite">
            <div className="message-row message-row-ai">
              <span className="message-label">PANTHER_AI / 01</span>
              <p>
                I am the digital shadow of the Architect. Ask me anything about
                his tech stack or experience.
              </p>
            </div>
            <div className="message-row message-row-user">
              <span className="message-label">YOU / QUERY</span>
              <p>{userMessage}</p>
            </div>
          </div>

          <form className="chat-input" onSubmit={submitQuery}>
            <label className="sr-only" htmlFor="panther-query">
              Type your query
            </label>
            <input
              id="panther-query"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Type your query..."
              autoComplete="off"
            />
            <button type="submit" aria-label="Send query">
              <span aria-hidden="true">&gt;_</span>
            </button>
          </form>

          <div className="chat-footer">
            <span>MODEL / SHADOW-01</span>
            <span>24MS</span>
          </div>
        </div>
      )}

      <div className="chat-toggle-wrap">
        <span className="toggle-status">
          {isOpen ? "SHADOW ACTIVE" : "SUMMON SHADOW"}
        </span>
        <button
          className="chat-toggle"
          type="button"
          aria-label={isOpen ? "Close Panther AI" : "Open Panther AI"}
          aria-expanded={isOpen}
          onClick={() => setIsOpen((open) => !open)}
        >
          <span className="toggle-ring" aria-hidden="true" />
          <PantherMark />
        </button>
      </div>
    </aside>
  )
}

function ProjectVisual({ type }: { type: (typeof featuredProjects)[number]["type"] }) {
  if (type === "anomaly") {
    return (
      <svg viewBox="0 0 540 320" aria-hidden="true">
        <g className="project-grid-lines">
          {[50, 105, 160, 215, 270].map((y) => (
            <line x1="30" x2="510" y1={y} y2={y} key={y} />
          ))}
          {[30, 126, 222, 318, 414, 510].map((x) => (
            <line x1={x} x2={x} y1="25" y2="295" key={x} />
          ))}
        </g>
        <path
          className="project-data-line"
          d="M30 230C70 226 83 208 121 215S171 242 207 210 254 180 284 196 327 217 353 184 386 74 411 105 449 205 510 145"
        />
        <path
          className="project-data-line project-data-line-muted"
          d="M30 256C81 235 118 249 154 228S220 246 259 221 321 243 359 228 431 239 510 216"
        />
        <circle className="project-alert-ring" cx="394" cy="93" r="21" />
        <circle className="project-alert" cx="394" cy="93" r="4" />
        <g className="project-chart-label">
          <rect x="415" y="55" width="86" height="27" />
          <text x="427" y="72">
            ANOMALY 0.94
          </text>
        </g>
      </svg>
    )
  }

  if (type === "forecast") {
    return (
      <svg viewBox="0 0 540 320" aria-hidden="true">
        <g className="project-grid-lines">
          {[50, 105, 160, 215, 270].map((y) => (
            <line x1="30" x2="510" y1={y} y2={y} key={y} />
          ))}
        </g>
        <path
          className="forecast-range"
          d="M30 245C91 226 128 229 182 196S267 171 319 133 401 95 510 46L510 126C421 141 369 175 314 185S232 218 179 235 95 264 30 273Z"
        />
        <path
          className="project-data-line"
          d="M30 258C91 244 130 243 182 215S270 194 319 159 406 123 510 83"
        />
        <path className="forecast-divider" d="M319 35V282" />
        <g className="forecast-dots">
          {[70, 118, 172, 222, 274].map((x, index) => (
            <circle cx={x} cy={[241, 235, 219, 203, 188][index]} r="3" key={x} />
          ))}
        </g>
        <text className="project-axis-copy" x="335" y="55">
          PREDICTED RANGE
        </text>
      </svg>
    )
  }

  return (
    <svg viewBox="0 0 540 320" aria-hidden="true">
      <g className="vault-links">
        <path d="M91 78 217 155 92 244M217 155l119-89M217 155l129 105M336 66l112 96M346 260l102-98" />
      </g>
      <g className="vault-nodes">
        <circle cx="91" cy="78" r="28" />
        <circle cx="92" cy="244" r="28" />
        <circle cx="217" cy="155" r="42" />
        <circle cx="336" cy="66" r="28" />
        <circle cx="346" cy="260" r="28" />
        <circle cx="448" cy="162" r="37" />
      </g>
      <g className="vault-centers">
        <circle cx="91" cy="78" r="4" />
        <circle cx="92" cy="244" r="4" />
        <circle className="vault-center-active" cx="217" cy="155" r="6" />
        <circle cx="336" cy="66" r="4" />
        <circle cx="346" cy="260" r="4" />
        <circle cx="448" cy="162" r="5" />
      </g>
      <g className="project-chart-label">
        <rect x="244" y="125" width="90" height="27" />
        <text x="255" y="142">
          IDENTITY MATCH
        </text>
      </g>
    </svg>
  )
}

function InteractiveChart() {
  const [period, setPeriod] = useState<ChartPeriod>("1 Month")
  const [activePoint, setActivePoint] = useState<number | null>(null)
  const values = chartSeries[period]
  const chartWidth = 820
  const chartHeight = 280
  const horizontalPadding = 18
  const verticalPadding = 22
  const maxValue = 100
  const points = values.map((value, index) => ({
    x:
      horizontalPadding +
      (index * (chartWidth - horizontalPadding * 2)) / (values.length - 1),
    y:
      chartHeight -
      verticalPadding -
      (value / maxValue) * (chartHeight - verticalPadding * 2),
    value,
  }))
  const linePoints = points.map((point) => `${point.x},${point.y}`).join(" ")
  const areaPoints = `${horizontalPadding},${chartHeight - verticalPadding} ${linePoints} ${
    chartWidth - horizontalPadding
  },${chartHeight - verticalPadding}`
  const change = values[values.length - 1] - values[0]

  return (
    <div className="dashboard">
      <div className="dashboard-toolbar">
        <div className="dashboard-id">
          <span className="live-indicator" />
          <div>
            <span>LIVE MODEL</span>
            <strong>Signal Extraction Index</strong>
          </div>
        </div>

        <div className="period-tabs" aria-label="Chart time range">
          {(Object.keys(chartSeries) as ChartPeriod[]).map((option) => (
            <button
              className={option === period ? "period-tab period-tab-active" : "period-tab"}
              type="button"
              aria-pressed={option === period}
              onClick={() => {
                setPeriod(option)
                setActivePoint(null)
              }}
              key={option}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="dashboard-metrics">
        <div className="primary-metric">
          <span>MODEL CONFIDENCE</span>
          <strong>{values[values.length - 1]}.0%</strong>
          <small>+{change}.0 pts</small>
        </div>
        <div className="secondary-metrics">
          <div>
            <span>SAMPLES</span>
            <strong>{period === "7 Days" ? "18.4K" : period === "1 Month" ? "84.2K" : "1.02M"}</strong>
          </div>
          <div>
            <span>NOISE REDUCTION</span>
            <strong>{period === "1 Year" ? "71.8%" : "64.2%"}</strong>
          </div>
        </div>
      </div>

      <div className="chart-wrap">
        <div className="chart-y-labels" aria-hidden="true">
          <span>100</span>
          <span>75</span>
          <span>50</span>
          <span>25</span>
          <span>0</span>
        </div>

        <svg
          className="data-chart"
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          role="img"
          aria-label={`${period} signal extraction trend, currently ${values[values.length - 1]} percent`}
        >
          <defs>
            <linearGradient id="chartArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FF6B00" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#FF6B00" stopOpacity="0" />
            </linearGradient>
            <filter id="lineGlow" x="-20%" y="-30%" width="140%" height="160%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g className="chart-grid">
            {[22, 81, 140, 199, 258].map((y) => (
              <line x1="18" x2="802" y1={y} y2={y} key={y} />
            ))}
            {[18, 214, 410, 606, 802].map((x) => (
              <line x1={x} x2={x} y1="22" y2="258" key={x} />
            ))}
          </g>

          <polygon className="chart-area" points={areaPoints} />
          <polyline className="chart-line" points={linePoints} />

          <g className="chart-points">
            {points.map((point, index) => (
              <g
                className="chart-point"
                role="button"
                tabIndex={0}
                aria-label={`Data point ${index + 1}: ${point.value} percent`}
                onMouseEnter={() => setActivePoint(index)}
                onMouseLeave={() => setActivePoint(null)}
                onFocus={() => setActivePoint(index)}
                onBlur={() => setActivePoint(null)}
                key={`${period}-${index}`}
              >
                <circle className="point-hit" cx={point.x} cy={point.y} r="14" />
                <circle
                  className={activePoint === index ? "point-dot point-dot-active" : "point-dot"}
                  cx={point.x}
                  cy={point.y}
                  r={activePoint === index ? 5 : 3}
                />
              </g>
            ))}
          </g>

          {activePoint !== null && (
            <g
              className="chart-tooltip"
              transform={`translate(${Math.min(Math.max(points[activePoint].x - 44, 4), 728)} ${
                Math.max(points[activePoint].y - 58, 4)
              })`}
            >
              <rect width="88" height="42" rx="2" />
              <text x="10" y="15">
                SIGNAL
              </text>
              <text className="tooltip-value" x="10" y="32">
                {points[activePoint].value}.0%
              </text>
            </g>
          )}
        </svg>

        <div className="chart-x-labels" aria-hidden="true">
          <span>START</span>
          <span>25%</span>
          <span>50%</span>
          <span>75%</span>
          <span>NOW</span>
        </div>
      </div>

      <div className="dashboard-footer">
        <span>MODEL: SIGNAL_v4.8</span>
        <span>UPDATED IN REAL TIME</span>
      </div>
    </div>
  )
}

function PipelineIcon({ type }: { type: (typeof pipelineStages)[number]["type"] }) {
  if (type === "sources") {
    return (
      <svg viewBox="0 0 40 40" aria-hidden="true">
        <ellipse cx="20" cy="9" rx="12" ry="5" />
        <path d="M8 9v10c0 2.8 5.4 5 12 5s12-2.2 12-5V9M8 19v11c0 2.8 5.4 5 12 5s12-2.2 12-5V19" />
        <path d="M8 14c0 2.8 5.4 5 12 5s12-2.2 12-5" />
      </svg>
    )
  }

  if (type === "processing") {
    return (
      <svg viewBox="0 0 40 40" aria-hidden="true">
        <rect x="10" y="10" width="20" height="20" />
        <rect x="15" y="15" width="10" height="10" />
        <path d="M15 4v6M25 4v6M15 30v6M25 30v6M4 15h6M4 25h6M30 15h6M30 25h6" />
      </svg>
    )
  }

  if (type === "vault") {
    return (
      <svg viewBox="0 0 40 40" aria-hidden="true">
        <path d="M6 13 20 6l14 7-14 7-14-7Z" />
        <path d="m6 20 14 7 14-7M6 27l14 7 14-7" />
        <path d="M6 13v14M34 13v14" />
      </svg>
    )
  }

  return (
    <svg viewBox="0 0 40 40" aria-hidden="true">
      <circle cx="8" cy="20" r="3" />
      <circle cx="31" cy="9" r="3" />
      <circle cx="31" cy="31" r="3" />
      <circle cx="20" cy="20" r="4" />
      <path d="m11 20 5 0M23 17l5-6M23 23l5 6" />
    </svg>
  )
}

function AboutIcon({ type }: { type: "focus" | "architecture" | "story" }) {
  if (type === "focus") {
    return (
      <svg viewBox="0 0 32 32" aria-hidden="true">
        <circle cx="16" cy="16" r="8" />
        <circle cx="16" cy="16" r="2" />
        <path d="M16 3v4M16 25v4M3 16h4M25 16h4" />
      </svg>
    )
  }

  if (type === "architecture") {
    return (
      <svg viewBox="0 0 32 32" aria-hidden="true">
        <rect x="4" y="5" width="9" height="8" />
        <rect x="19" y="19" width="9" height="8" />
        <path d="M13 9h7a4 4 0 0 1 4 4v6M8 13v7a3 3 0 0 0 3 3h8" />
      </svg>
    )
  }

  return (
    <svg viewBox="0 0 32 32" aria-hidden="true">
      <path d="M5 25V15M12 25V9M19 25V18M26 25V5" />
      <path d="m5 12 7-6 7 8 7-12" />
      <circle cx="5" cy="12" r="1.5" />
      <circle cx="12" cy="6" r="1.5" />
      <circle cx="19" cy="14" r="1.5" />
      <circle cx="26" cy="2" r="1.5" />
    </svg>
  )
}

export default function App() {
  return (
    <main className="site-shell">
      <header className="site-header">
        <a className="brand" href="#" aria-label="Portfolio home">
          <span className="brand-mark">D/</span>
          <span className="brand-name">DATA SYSTEMS</span>
        </a>

        <div className="availability">
          <span className="availability-dot" />
          Available for select projects
        </div>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-copy">
          <div className="eyebrow">
            <span className="eyebrow-line" />
            Data Scientist · Data Engineer
          </div>

          <h1 id="hero-title">
            Transforming the Unknown into <em>Strategic Insights.</em>
          </h1>

          <p className="hero-description">
            I build stealthy data pipelines and clear predictive models. Let&apos;s
            uncover the signal in the fog.
          </p>

          <div className="hero-actions">
            <a className="button button-primary" href="#work">
              Explore My Data
              <span aria-hidden="true">↗</span>
            </a>
            <a
              className="button button-secondary"
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
            >
              View GitHub
            </a>
          </div>

          <div className="hero-index" aria-hidden="true">
            <span>DS — 001</span>
            <span>MODELING THE UNSEEN</span>
          </div>
        </div>

        <div className="hero-visual">
          <DataNetwork />
        </div>
      </section>

      <section className="about" id="about" aria-labelledby="about-title">
        <div className="about-inner">
          <div className="about-visual">
            <div className="portrait-frame" aria-label="Portrait image placeholder">
              <div className="portrait-grid" />
              <div className="portrait-index">
                <span>PORTRAIT / 01</span>
                <span>FOCUS: LOCKED</span>
              </div>
              <div className="portrait-silhouette">
                <div className="silhouette-head" />
                <div className="silhouette-body" />
              </div>
              <div className="portrait-scanline" />
              <span className="portrait-corner portrait-corner-top" />
              <span className="portrait-corner portrait-corner-bottom" />
            </div>
          </div>

          <div className="about-copy">
            <p className="about-overline">/ Who I am</p>
            <h2 id="about-title">The Architect Behind the Fog.</h2>
            <p className="about-description">
              People usually see a quiet, highly focused engineer. That’s by
              design. I use silence to cut through the noise, engineering
              scalable and clean data pipelines with absolute precision. But
              once the pipeline is built, the orange glow appears—I transform
              complex data into compelling, easy-to-understand stories that
              drive team decisions.
            </p>

            <div className="about-strengths">
              <div className="strength">
                <span className="strength-icon">
                  <AboutIcon type="focus" />
                </span>
                <span>Deep Work Focus</span>
              </div>
              <div className="strength">
                <span className="strength-icon">
                  <AboutIcon type="architecture" />
                </span>
                <span>Scalable Architecture</span>
              </div>
              <div className="strength">
                <span className="strength-icon">
                  <AboutIcon type="story" />
                </span>
                <span>Data Storytelling</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stack" id="work" aria-labelledby="stack-title">
        <div className="stack-inner">
          <header className="stack-heading">
            <p className="stack-overline">/ The Arsenal</p>
            <h2 id="stack-title">Weapons of Choice.</h2>
            <p className="stack-intro">
              Precision tools I use to engineer pipelines, train models, and deploy
              scalable solutions.
            </p>
          </header>

          <div className="stack-grid">
            {stackCategories.map((category) => (
              <article className="stack-card" key={category.title}>
                <div className="card-topline">
                  <span className="card-number">{category.number}</span>
                  <span className="card-mark" aria-hidden="true">
                    <i />
                    <i />
                    <i />
                  </span>
                </div>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <div className="tool-list" aria-label={`${category.title} technologies`}>
                  {category.tools.map((tool) => (
                    <span className="tool-tag" key={tool}>
                      {tool}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>

          <p className="interaction-note">
            <span className="interaction-symbol" aria-hidden="true">
              +
            </span>
            Hover over a technology to illuminate the stack
          </p>
        </div>
      </section>

      <section className="architecture" aria-labelledby="architecture-title">
        <div className="architecture-inner">
          <header className="architecture-heading">
            <p className="architecture-overline">/ The Blueprint</p>
            <h2 id="architecture-title">Systematic by Design.</h2>
            <p className="architecture-intro">
              I don&apos;t just write code; I design scalable systems. Here is how
              I process chaotic data into actionable intelligence.
            </p>
          </header>

          <div className="pipeline-shell">
            <div className="pipeline-meta" aria-hidden="true">
              <span>ARCH / 001</span>
              <span>FLOW STATUS: ACTIVE</span>
            </div>

            <div className="pipeline">
              {pipelineStages.map((stage, index) => (
                <div className="pipeline-segment" key={stage.number}>
                  <article className="pipeline-node">
                    <div className="pipeline-node-top">
                      <span>{stage.label}</span>
                      <span>{stage.number}</span>
                    </div>
                    <span className="pipeline-icon">
                      <PipelineIcon type={stage.type} />
                    </span>
                    <h3>
                      <span>{stage.number}.</span> {stage.title}
                      {"suffix" in stage && (
                        <small>{stage.suffix}</small>
                      )}
                    </h3>
                    <p>{stage.detail}</p>
                    <span className="node-status" aria-hidden="true">
                      ONLINE
                    </span>
                  </article>

                  {index < pipelineStages.length - 1 && (
                    <div className="pipeline-connector" aria-hidden="true">
                      <span className="flow-pulse" />
                      <span className="flow-arrow" />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="pipeline-scale" aria-hidden="true">
              <span>00</span>
              <span>25</span>
              <span>50</span>
              <span>75</span>
              <span>100</span>
            </div>
          </div>
        </div>
      </section>

      <section className="sandbox" id="sandbox" aria-labelledby="sandbox-title">
        <div className="sandbox-inner">
          <header className="sandbox-heading">
            <p className="sandbox-overline">/ The Sandbox</p>
            <h2 id="sandbox-title">Data in Motion.</h2>
            <p className="sandbox-intro">
              Don&apos;t just take my word for it. Interact with the live data model
              below to see how I extract signals from the noise.
            </p>
          </header>

          <InteractiveChart />

          <p className="sandbox-hint">
            <span aria-hidden="true">+</span>
            Select a range and hover over the data points to inspect the model
          </p>
        </div>
      </section>

      <section className="projects" aria-labelledby="projects-title">
        <div className="projects-inner">
          <header className="projects-heading">
            <p className="projects-overline">/ Battle-Tested Projects</p>
            <h2 id="projects-title">Proof of Execution.</h2>
            <p className="projects-intro">
              Theory is just noise until it’s deployed. Here are a few times I
              cleared the fog and delivered real results.
            </p>
          </header>

          <div className="projects-list">
            {featuredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-visual">
                  <div className="project-visual-meta">
                    <span>PROJECT / {project.index}</span>
                    <span>EXECUTED</span>
                  </div>
                  <ProjectVisual type={project.type} />
                  <span className="visual-corner visual-corner-one" />
                  <span className="visual-corner visual-corner-two" />
                </div>

                <div className="project-copy">
                  <div className="project-index">
                    <span>CASE STUDY {project.index}</span>
                    <span>{project.stack}</span>
                  </div>
                  <h3>{project.title}</h3>

                  <dl className="project-details">
                    <div>
                      <dt>The Fog</dt>
                      <dd>{project.fog}</dd>
                    </div>
                    <div>
                      <dt>The Strategy</dt>
                      <dd>{project.strategy}</dd>
                    </div>
                    <div className="project-result">
                      <dt>The Vision</dt>
                      <dd>{project.vision}</dd>
                    </div>
                  </dl>

                  <div className="project-actions">
                    <a href="https://github.com" target="_blank" rel="noreferrer">
                      View Code
                      <span aria-hidden="true">↗</span>
                    </a>
                    <a href="#sandbox">
                      Live Demo
                      <span aria-hidden="true">→</span>
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="experience" aria-labelledby="experience-title">
        <div className="experience-inner">
          <header className="experience-heading">
            <p className="experience-overline">/ The Evolution</p>
            <h2 id="experience-title">Tracing the Hunt.</h2>
            <p className="experience-intro">
              From writing the first script to architecting complex data
              ecosystems. Here is the path I’ve walked.
            </p>
          </header>

          <div className="timeline">
            <div className="timeline-line" aria-hidden="true">
              <span className="timeline-flow" />
            </div>

            {experienceTimeline.map((entry, index) => (
              <article
                className={
                  index % 2 === 0
                    ? "timeline-entry timeline-entry-left"
                    : "timeline-entry timeline-entry-right"
                }
                key={`${entry.year}-${entry.role}`}
              >
                <div className="timeline-content">
                  <div className="timeline-meta">
                    <span>{entry.focus}</span>
                    <span>0{experienceTimeline.length - index}</span>
                  </div>
                  <time>{entry.year}</time>
                  <h3>{entry.role}</h3>
                  <p>{entry.description}</p>
                </div>

                <div className="timeline-node" aria-hidden="true">
                  <span />
                </div>
              </article>
            ))}
          </div>

          <div className="timeline-origin" aria-hidden="true">
            <span>ORIGIN POINT</span>
          </div>
        </div>
      </section>

      <section className="philosophy" aria-labelledby="philosophy-title">
        <div className="philosophy-inner">
          <header className="philosophy-heading">
            <p className="philosophy-overline">/ The Philosophy</p>
            <h2 id="philosophy-title">Principles Over Syntax.</h2>
            <p className="philosophy-intro">
              Languages change. Frameworks die. But a solid engineering mindset
              scales forever. These are the laws I code by.
            </p>
          </header>

          <div className="principles-grid">
            {engineeringPrinciples.map((principle) => (
              <article className="principle-card" key={principle.number}>
                <div className="principle-top">
                  <span className="principle-number">{principle.number}</span>
                  <span className="principle-symbol" aria-hidden="true">
                    <i />
                    <i />
                  </span>
                </div>

                <div className="principle-copy">
                  <h3>{principle.title}</h3>
                  <p>{principle.description}</p>
                </div>

                <div className="principle-footer">
                  <span>{principle.code}</span>
                  <span aria-hidden="true">+</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="telemetry" aria-labelledby="telemetry-title">
        <div className="telemetry-inner">
          <header className="telemetry-heading">
            <p className="telemetry-overline">/ Live Telemetry</p>
            <h2 id="telemetry-title">The Pulse of the Engineer.</h2>
            <p className="telemetry-intro">
              Real-time metrics from my personal APIs. Because what kind of data
              engineer doesn&apos;t track their own data?
            </p>
          </header>

          <div className="telemetry-console">
            <div className="console-bar">
              <div className="console-id">
                <span className="console-crosshair" aria-hidden="true" />
                <span>PERSONAL_OS / TELEMETRY</span>
              </div>
              <div className="console-status">
                <span>API CONNECTED</span>
                <span>POLL: 60S</span>
              </div>
            </div>

            <div className="metrics-grid">
              <article className="metric-card commits-card">
                <div className="metric-topline">
                  <span>01 / GITHUB</span>
                  <span className="metric-signal" aria-hidden="true">
                    <i />
                    <i />
                    <i />
                  </span>
                </div>
                <p className="metric-label">GitHub Commits</p>
                <p className="metric-context">Last 30 Days</p>
                <div className="metric-value-row">
                  <strong>184</strong>
                  <span>+12.4%</span>
                </div>
                <div className="commit-graph" aria-hidden="true">
                  {[2, 4, 3, 5, 7, 4, 6, 8, 5, 7, 9, 6, 8, 10].map(
                    (height, index) => (
                      <i
                        className={index > 10 ? "commit-bar commit-bar-active" : "commit-bar"}
                        style={{ height: `${height * 3}px` }}
                        key={`${height}-${index}`}
                      />
                    ),
                  )}
                </div>
              </article>

              <article className="metric-card listening-card">
                <div className="metric-topline">
                  <span>02 / SPOTIFY API</span>
                  <svg className="music-icon" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M9 17V5l10-2v12M9 8l10-2" />
                    <circle cx="6" cy="18" r="3" />
                    <circle cx="16" cy="16" r="3" />
                  </svg>
                </div>
                <p className="metric-label">Now Listening</p>
                <div className="track-info">
                  <span className="album-art" aria-hidden="true">
                    <i />
                  </span>
                  <div>
                    <strong>Midnight Signal</strong>
                    <span>Data After Dark</span>
                  </div>
                </div>
                <div className="audio-wave" aria-hidden="true">
                  {[4, 9, 15, 8, 18, 12, 20, 9, 16, 6, 12, 4].map(
                    (height, index) => (
                      <i style={{ height: `${height}px` }} key={`${height}-${index}`} />
                    ),
                  )}
                </div>
              </article>

              <article className="metric-card status-card">
                <div className="metric-topline">
                  <span>03 / INFRASTRUCTURE</span>
                  <span className="uptime">99.99%</span>
                </div>
                <p className="metric-label">System Status</p>
                <div className="system-online">
                  <span className="online-orbit" aria-hidden="true">
                    <i />
                  </span>
                  <strong>Online</strong>
                </div>
                <div className="system-stats">
                  <span>
                    LATENCY <strong>24ms</strong>
                  </span>
                  <span>
                    SERVICES <strong>08/08</strong>
                  </span>
                </div>
              </article>
            </div>

            <div className="console-footer">
              <span>LAST SYNC: JUST NOW</span>
              <span>ALL SYSTEMS NOMINAL</span>
            </div>
          </div>
        </div>
      </section>

      <section className="postmortems" aria-labelledby="postmortems-title">
        <div className="postmortems-inner">
          <header className="postmortems-heading">
            <p className="postmortems-overline">/ Post-Mortems</p>
            <h2 id="postmortems-title">Scars of the Hunt.</h2>
            <p className="postmortems-intro">
              Every engineer has crashed a pipeline. The difference is how we
              rebuild it. Here are my favorite failures and what they taught me.
            </p>
          </header>

          <div className="postmortem-grid">
            {postMortems.map((incident, index) => (
              <article className="postmortem-card" key={incident.id}>
                <div className="incident-header">
                  <div>
                    <span>{incident.id}</span>
                    <span>{incident.date}</span>
                  </div>
                  <span className="resolved-status">
                    <i aria-hidden="true" />
                    Resolved
                  </span>
                </div>

                <div className="incident-title-row">
                  <span className="incident-index">0{index + 1}</span>
                  <div>
                    <p>{incident.system}</p>
                    <h3>{incident.title}</h3>
                  </div>
                </div>

                <div className="incident-report">
                  <div className="incident-phase crash-phase">
                    <div className="phase-label">
                      <span className="warning-icon" aria-hidden="true">
                        !
                      </span>
                      <h4>The Crash</h4>
                    </div>
                    <p>{incident.crash}</p>
                  </div>

                  <div className="incident-phase">
                    <div className="phase-label">
                      <span className="phase-marker" aria-hidden="true" />
                      <h4>The Fix</h4>
                    </div>
                    <p>{incident.fix}</p>
                  </div>

                  <div className="incident-phase lesson-phase">
                    <div className="phase-label">
                      <span className="phase-marker" aria-hidden="true" />
                      <h4>The Lesson</h4>
                    </div>
                    <p>{incident.lesson}</p>
                  </div>
                </div>

                <footer className="incident-footer">
                  <span>{incident.terms}</span>
                  <span>STATUS / CLOSED</span>
                </footer>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="trophies" aria-labelledby="trophies-title">
        <div className="trophies-inner">
          <header className="trophies-heading">
            <p className="trophies-overline">/ Trophies &amp; Ranks</p>
            <h2 id="trophies-title">Certified in the Fog.</h2>
            <p className="trophies-intro">
              I don&apos;t just build pipelines in the dark. I validate my skills
              on global battlegrounds.
            </p>
          </header>

          <div className="trophy-room">
            <div className="trophy-room-meta" aria-hidden="true">
              <span>VERIFIED CREDENTIALS</span>
              <span>VAULT / 04</span>
            </div>

            <div className="badges-grid">
              {certifications.map((certification) => (
                <article className="badge-item" key={certification.title}>
                  <span className="badge-rank">{certification.rank}</span>
                  <div className="badge-mark">
                    <CertificationBadge type={certification.type} />
                  </div>
                  <h3>{certification.title}</h3>
                  <p>{certification.subtitle}</p>
                  <span className="badge-verified">
                    <i aria-hidden="true" />
                    Verified
                  </span>
                </article>
              ))}
            </div>

            <div className="trophy-plinth" aria-hidden="true">
              <span />
            </div>
          </div>
        </div>
      </section>

      <section className="logbook" aria-labelledby="logbook-title">
        <div className="logbook-inner">
          <header className="logbook-heading">
            <p className="logbook-overline">/ The Logbook</p>
            <h2 id="logbook-title">Translating Complexity.</h2>
            <p className="logbook-intro">
              I speak Python to machines, but I translate it into strategy for
              humans. Here are a few thoughts from the field.
            </p>
          </header>

          <div className="journal-header" aria-hidden="true">
            <span>FIELD NOTES / 2025</span>
            <span>04 ENTRIES</span>
          </div>

          <div className="logbook-grid">
            {logbookEntries.map((entry, index) => (
              <article className="logbook-entry" key={entry.title}>
                <div className="entry-meta">
                  <time>{entry.date}</time>
                  <span>{entry.readTime}</span>
                </div>
                <p className="entry-category">
                  <span>0{index + 1}</span>
                  {entry.category}
                </p>
                <h3>{entry.title}</h3>
                <p className="entry-excerpt">{entry.excerpt}</p>
                <a className="entry-link" href="#logbook-title">
                  Read More
                  <span aria-hidden="true">→</span>
                </a>
              </article>
            ))}
          </div>

          <div className="journal-footer">
            <span>END OF CURRENT LOG</span>
            <span aria-hidden="true" />
          </div>
        </div>
      </section>

      <section className="contact" aria-labelledby="contact-title">
        <div className="contact-orbit contact-orbit-one" aria-hidden="true" />
        <div className="contact-orbit contact-orbit-two" aria-hidden="true" />

        <div className="contact-inner">
          <header className="contact-heading">
            <p className="contact-overline">/ Initiate Contact</p>
            <h2 id="contact-title">Ready to Clear the Fog?</h2>
            <p className="contact-intro">
              No messy contact forms. Just direct lines to my terminal. If you
              have a data problem, let’s build a solution.
            </p>
          </header>

          <div className="contact-actions">
            <a
              className="contact-button contact-button-secondary"
              href="https://www.linkedin.com"
              target="_blank"
              rel="noreferrer"
            >
              <span>LinkedIn</span>
              <span aria-hidden="true">↗</span>
            </a>
            <a
              className="contact-button contact-button-primary"
              href="mailto:hello@example.com"
            >
              <span>Send an Email</span>
              <span aria-hidden="true">→</span>
            </a>
            <a
              className="contact-button contact-button-secondary"
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
            >
              <span>GitHub</span>
              <span aria-hidden="true">↗</span>
            </a>
          </div>

          <div className="contact-status">
            <span className="contact-status-dot" />
            <span>LINE OPEN / AVAILABLE FOR SELECT PROJECTS</span>
          </div>
        </div>

        <footer className="site-footer">
          <span>© 2025 DATA SYSTEMS</span>
          <span>ENGINEERED WITH INTENT</span>
          <a href="#">RETURN TO ORIGIN ↑</a>
        </footer>
      </section>

      <PantherChat />
    </main>
  )
}
