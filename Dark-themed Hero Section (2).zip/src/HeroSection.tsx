import { Component, createRef } from "react"
import Particles, { type ParticlesProps } from "react-tsparticles"
import { loadFull } from "tsparticles"
import FOG from "vanta/dist/vanta.fog.min"

type ThreeRuntime = typeof import("three")

declare global {
  interface Window {
    __PORTFOLIO_THREE__?: ThreeRuntime
    __THREE__?: string
    THREE?: ThreeRuntime
  }
}

type FogEffect = {
  destroy: () => void
}

type FogFactory = (options: {
  el: HTMLElement
  THREE: ThreeRuntime
  mouseControls: boolean
  touchControls: boolean
  gyroControls: boolean
  minHeight: number
  minWidth: number
  highlightColor: number
  midtoneColor: number
  lowlightColor: number
  baseColor: number
  blurFactor: number
  speed: number
  zoom: number
}) => FogEffect

// Vanta ships this effect as UMD. Vite exposes that bundle as either the
// factory itself or a nested default depending on dev/prebundle mode.
const fogModule = FOG as unknown as FogFactory | { default: FogFactory }
const createFog: FogFactory =
  typeof fogModule === "function" ? fogModule : fogModule.default

const initializeParticles: NonNullable<ParticlesProps["init"]> = async (engine) => {
  await loadFull(engine)
}

const particleOptions: ParticlesProps["options"] = {
  fullScreen: { enable: false },
  background: { color: { value: "transparent" } },
  detectRetina: true,
  fpsLimit: 60,
  particles: {
    color: {
      value: ["#ff6b00", "#d7d7d2", "#777773"],
    },
    links: {
      color: "#ff6b00",
      distance: 155,
      enable: true,
      opacity: 0.24,
      width: 1,
      triangles: {
        enable: true,
        color: "#ff6b00",
        opacity: 0.018,
      },
    },
    move: {
      direction: "none",
      enable: true,
      outModes: {
        default: "out",
      },
      random: false,
      speed: 0.72,
      straight: false,
    },
    number: {
      density: {
        enable: true,
        area: 700,
      },
      value: 42,
    },
    opacity: {
      value: { min: 0.28, max: 0.82 },
      animation: {
        enable: true,
        speed: 0.35,
        minimumValue: 0.2,
        sync: false,
      },
    },
    shape: {
      type: "circle",
    },
    size: {
      value: { min: 1, max: 3.2 },
      animation: {
        enable: true,
        speed: 1.2,
        minimumValue: 0.8,
        sync: false,
      },
    },
  },
  interactivity: {
    detectsOn: "window",
    events: {
      onHover: {
        enable: true,
        mode: ["grab", "repulse"],
      },
      onClick: {
        enable: true,
        mode: "push",
      },
      resize: true,
    },
    modes: {
      grab: {
        distance: 185,
        links: {
          opacity: 0.78,
        },
      },
      repulse: {
        distance: 82,
        duration: 0.45,
      },
      push: {
        quantity: 3,
      },
    },
  },
}

export default class HeroSection extends Component {
  private readonly fogRef = createRef<HTMLDivElement>()
  private fogEffect: FogEffect | null = null
  private fogInitialization = 0

  componentDidMount() {
    const initialization = ++this.fogInitialization
    void this.initializeFog(initialization)
  }

  componentWillUnmount() {
    this.fogInitialization += 1
    this.fogEffect?.destroy()
    this.fogEffect = null
  }

  private async initializeFog(initialization: number) {
    let threeRuntime = window.__PORTFOLIO_THREE__

    if (!threeRuntime) {
      // Three uses this marker only to report duplicate imports. Clear a stale
      // HMR marker before loading the one runtime this component owns.
      delete window.__THREE__

      const threeModule = await import("vanta/vendor/three.r134.min")
      const moduleRuntime = threeModule.default

      // The raw UMD file publishes to window.THREE in Vite dev, while the
      // production CommonJS interop exposes the same object as `default`.
      threeRuntime =
        typeof moduleRuntime?.Color === "function" ? moduleRuntime : window.THREE

      if (!threeRuntime || typeof threeRuntime.Color !== "function") {
        throw new Error("Vanta Three runtime failed to initialize")
      }

      window.__PORTFOLIO_THREE__ = threeRuntime
    }

    if (
      initialization !== this.fogInitialization ||
      !this.fogRef.current ||
      this.fogEffect
    ) {
      return
    }

    this.fogEffect = createFog({
      el: this.fogRef.current,
      THREE: threeRuntime,
      mouseControls: true,
      touchControls: true,
      gyroControls: false,
      minHeight: 200,
      minWidth: 200,
      highlightColor: 0xff6b00,
      midtoneColor: 0x291005,
      lowlightColor: 0x070503,
      baseColor: 0x000000,
      blurFactor: 0.64,
      speed: 1.15,
      zoom: 0.82,
    })
  }

  render() {
    return (
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-vanta" ref={this.fogRef} aria-hidden="true" />
        <Particles
          id="hero-data-network"
          className="hero-particles"
          init={initializeParticles}
          options={particleOptions}
        />
        <img
          className="panther-centerpiece"
          src="/assets/panther-data-network.png"
          alt="Glowing orange wireframe panther formed from connected data nodes"
        />

        <div className="hero-content">
          <div className="hero-copy">
            <div className="eyebrow">
              <span className="eyebrow-line" />
              Data Scientist · Data Engineer
            </div>

            <h1 id="hero-title">
              Transforming the Unknown into <em>Strategic Insights.</em>
            </h1>

            <p className="hero-description">
              I build stealthy data pipelines and clear predictive models. Let&apos;s
              uncover the signal in the fog.
            </p>

            <div className="hero-actions">
              <a className="button button-primary" href="#work">
                [ Explore My Data ]
              </a>
              <a className="button button-download" href="#about">
                [ Download CV ]
              </a>
            </div>

            <div className="hero-index" aria-hidden="true">
              <span>DS — 001</span>
              <span>MODELING THE UNSEEN</span>
            </div>
          </div>

          <div className="hero-visual" aria-label="Interactive data network">
            <div className="particle-readout particle-readout-top" aria-hidden="true">
              <span>01</span>
              <span>LIVE NODES</span>
            </div>
            <div
              className="particle-readout particle-readout-bottom"
              aria-hidden="true"
            >
              <span>02</span>
              <span>HOVER TO INTERACT</span>
            </div>
          </div>
        </div>
      </section>
    )
  }
}
